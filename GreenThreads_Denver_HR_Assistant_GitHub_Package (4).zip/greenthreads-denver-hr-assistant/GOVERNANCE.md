# Governance and Decision Rights

## Human review

The assistant supports decisions but does not make them.

- **Jennifer, CFO:** accountable for compensation rates, recurring payroll commitments, and budget approval.
- **Daira Beckum, HR Team Lead:** accountable for revised offer letters, candidate communication, and approved start-date execution.
- **Hiring manager:** accountable for evaluating qualifications and making final hiring decisions.
- **Thierry Njalenga, Finance Liaison:** accountable for checking formulas, distinguishing budget periods, and reporting actual hiring and spending results.

## Accountability when the assistant is wrong

The person who reviews and approves the action remains accountable. AI output is not approval. If a compensation calculation is wrong, the CFO and Finance Liaison must stop the action and correct it before offers are issued. If a candidate recommendation is wrong or unfair, HR and the hiring manager must review the evidence and make the final decision.

## Privacy and access

- Raw applicant records should remain inside the authorized GreenThreads HR environment.
- Public GitHub materials must use aggregated or de-identified information.
- Do not publish applicant names, contact details, or applicant-level personal information.
- Limit access to employees who need the information for authorized hiring, finance, or launch work.
- Do not use protected or sensitive characteristics to recommend or reject candidates.

## Required review before action

| Assistant output | Required reviewer |
|---|---|
| Pay-rate or payroll recommendation | CFO and Finance Liaison |
| Revised offer or start-date language | CFO and HR Team Lead |
| Candidate screening or ranking | HR Team Lead and hiring manager |
| Staffing-gap report | HR Team Lead and Finance Liaison |
| Public report or repository content | HR Team Lead or instructor/project owner |

## Monitoring

After revised offers are approved, HR should record actual offers, acceptances, decline reasons, start dates, and payroll cost. The assistant may summarize the results, but it must not claim the intervention worked until post-change data exists.

