# GreenThreads Denver HR Finance Liaison Assistant

## Project overview

This ChatGPT Project supports the People Operations team for GreenThreads' Denver launch, Store #13. I built it from the same HR Finance Liaison work completed in Homework #1 through Homework #3. It is designed to help an employee who already has a full-time role quickly check staffing, pay, policy, timeline, and hiring-cost questions.

The assistant does not make hiring or compensation decisions. It organizes the evidence, shows its calculations, flags conflicts, and identifies the person who must review the result.

## Problem the assistant addresses

GreenThreads must prepare the Denver store within a 90-day launch period and a fixed budget. The store needs 14 employees. Seven offers have been accepted and seven positions remain open: six Sales Associate positions and one Stock Associate position.

Sales Associate hiring is the largest problem:

- 88 applicants applied for eight authorized Sales Associate positions.
- 11 offers were extended, two were accepted, and nine were declined.
- The offer-acceptance rate is 18.2%.
- Five of nine declined offers cited pay below expectations.
- Three cited a start date that was too far away.
- The $17.50 hourly offer is below the $19.75 Denver market rate.
- The handbook requires hourly retail pay at or above the local market median.
- The job posting advertised an August target start, but the offer letter proposed September 28.

## Assistant name

**GreenThreads Denver HR Finance Liaison**

## Persona, Task, Context, and Format

### Persona

Act as the people-operations analyst and HR Finance Liaison for GreenThreads' Denver launch, Store #13. Support staffing, pay, policy, timeline, and hiring-cost decisions. Do not replace the CFO, HR Team Lead, or hiring manager.

### Task

For every request:

1. Check pay, staffing, and timeline claims against the approved project documents.
2. Break staffing gaps down by role.
3. Separate confirmed figures from targets, estimates, ceilings, and proposals.
4. Show formulas for financial calculations.
5. Flag contradictions between the applicant data, handbook, posting, offer letter, and launch timeline.
6. Identify missing information and the human reviewer required before action.

### Context

Work within the 90-day Denver launch clock and fixed staffing budget. Below-policy pay is a critical hiring risk. The handbook requires pay at or above the local market median, and pay is the leading stated reason Sales Associate candidates declined. Treat the August-versus-September start-date mismatch as a separate hiring risk.

### Format

- Use concise bullets, not long paragraphs.
- Label material claims **CONFIRMED**, **CONTRADICTS POLICY**, or **UNCONFIRMED**.
- Show role-level staffing gaps and calculation formulas.
- End every answer with **So what for HR:** followed by the immediate decision or next action.

The complete copy-and-paste instructions are in [`PROJECT_INSTRUCTIONS.md`](PROJECT_INSTRUCTIONS.md).

## Knowledge files

The private ChatGPT Project uses the GreenThreads case brief, Denver applicant dataset, Sales Associate offer letter, employee handbook/HR source documents, job posting, and the verified findings from Homework #1 through Homework #3.

The public repository does not include the raw applicant dataset because it contains sensitive applicant-level information. The file list and privacy decisions are documented in [`KNOWLEDGE_FILES.md`](KNOWLEDGE_FILES.md).

## Important verified calculations

- One-seat maximum annual base-wage adjustment:

  `$2.25 x 28 hours x 52 weeks = $3,276`

- Six vacant Sales Associate seats:

  `$3,276 x 6 = $19,656`

- All eight authorized Sales Associate positions:

  `$3,276 x 8 = $26,208`

The $19,656 amount applies to the six vacancies. The $26,208 amount applies only if GreenThreads adjusts all eight positions, including the two accepted hires. These are base-wage scenarios using the 28-hour weekly ceiling. They exclude payroll taxes and benefits.

## Testing and iteration

I ran five realistic tests and five break tests. The assistant correctly reported staffing gaps, pay differences, offer outcomes, and document conflicts. Testing also exposed two important failure risks:

1. Dividing the Denver sales target equally across employees to invent an exact lost-sales amount.
2. Subtracting a recurring annual wage adjustment from a pre-opening HR budget to invent a remaining recruiting cushion.

I added a named **Comparable-Scope and No-Invented-Productivity Guardrail**. It requires the assistant to confirm that costs use the same time period and scope, and it prohibits employee-level sales or profit estimates unless a project source supplies role-level productivity data.

See [`TESTING_AND_ITERATION.md`](TESTING_AND_ITERATION.md) for the prompts, results, failure, revision, and retest.

## Governance and decision rights

- Jennifer, CFO: approves compensation and budget changes.
- Daira Beckum, HR Team Lead: approves and communicates offer-letter and start-date changes.
- Hiring manager: reviews candidates and makes final hiring decisions.
- Thierry Njalenga, Finance Liaison: verifies calculations and monitors actual spending and acceptance results.

If the assistant gives an incorrect result, the human who reviews and approves the related decision remains accountable. The assistant is a decision-support tool, not the decision owner.

See [`GOVERNANCE.md`](GOVERNANCE.md) for the full controls.

## Repository contents

```text
greenthreads-denver-hr-assistant/
├── README.md
├── PROJECT_INSTRUCTIONS.md
├── KNOWLEDGE_FILES.md
├── TESTING_AND_ITERATION.md
├── GOVERNANCE.md
├── GITHUB_UPLOAD_STEPS.md
└── docs/
    ├── HW1_HR_Function_Summary.md
    ├── HW2_Document_Synthesis_Summary.md
    ├── HW3_Corrected_Findings.md
    └── AI205_HW3_Denver_Sales_Associate_Staffing_Corrected.pdf
```

## Limitation

The assistant cannot calculate exact payroll taxes, benefits, profit loss, employee-level sales productivity, or the effect of a pay change on future acceptance rates because the approved files do not contain those figures. It must label those questions unconfirmed rather than invent an answer.

## Public access check

After publishing, open the repository URL in a private or incognito browser window. The assignment is not complete until a reviewer who is not signed in can open it.

