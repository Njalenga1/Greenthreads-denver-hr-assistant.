# GitHub Publishing Steps

1. Sign in to GitHub and select **New repository**.
2. Name the repository `greenthreads-denver-hr-assistant`.
3. Set the repository to **Public**.
4. Upload every file and folder from this repository package.
5. Commit the files to the main branch.
6. Copy the public repository URL.
7. Paste the URL into the marked field in the Campuswire submission document.
8. Open the repository URL in a private or incognito browser window.
9. Confirm that the README and all public files open without signing in.
10. Submit the completed Google Doc on Campuswire.

Do not upload the raw Denver applicant dataset or any document containing applicant names, email addresses, phone numbers, or other applicant-level information.

