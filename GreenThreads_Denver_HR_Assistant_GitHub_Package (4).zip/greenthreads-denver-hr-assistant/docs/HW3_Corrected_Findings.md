# HW #3 - Corrected Findings

## Staffing

- Eight Sales Associate positions are authorized.
- Two offers were accepted.
- Six Sales Associate positions remain open.
- One Stock Associate position also remains open.
- Total Denver gap: seven positions.

## Sales Associate funnel

- 88 applicants
- 11 offers
- 2 accepted
- 9 declined
- 18.2% offer-acceptance rate

## Pay calculation

- Current offer: $17.50 per hour
- Denver market rate: $19.75 per hour
- Gap: $2.25 per hour
- Weekly ceiling: up to 28 hours
- Maximum annual additional cost per seat: `$2.25 x 28 x 52 = $3,276`
- Six-vacancy maximum: `$3,276 x 6 = $19,656`
- Eight-position policy adjustment: `$3,276 x 8 = $26,208`

These are base-wage scenarios only. They exclude payroll taxes, benefits, and other unpriced employer costs.

## Budget correction

The annual recurring wage adjustment should not be subtracted directly from the $65,000 pre-opening HR allocation. The actual pre-opening payroll effect depends on confirmed schedules and paid weeks during the budget period.

## Forecast correction

The files do not support an exact revenue-loss amount per vacancy or a guaranteed improvement in offer acceptance. Both must remain unconfirmed until GreenThreads collects the required post-change or productivity data.

