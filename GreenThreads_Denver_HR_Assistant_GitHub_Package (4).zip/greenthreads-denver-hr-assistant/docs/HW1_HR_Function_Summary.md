# HW #1 - HR Function Summary

GreenThreads HR supports hiring, fair labor practices, payroll and benefits, compliance, culture, and retention. For the Denver launch, the immediate challenge is filling the 14-person store team within the 90-day launch clock without adding corporate headcount.

The original AI opportunity was a reusable HR assistant that could reduce manual workload by screening information, checking policy, answering routine questions, and supporting staffing forecasts while keeping humans responsible for final decisions.

Main controls identified in HW #1:

- Human review of AI-supported candidate screening.
- No applicant or employee personal data in an unapproved public AI tool.
- Escalation of sensitive medical, harassment, disability, or accommodation questions to HR.

