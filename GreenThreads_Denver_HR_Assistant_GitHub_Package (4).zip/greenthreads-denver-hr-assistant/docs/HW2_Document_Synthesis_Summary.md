# HW #2 - Document Synthesis Summary

HW #2 compared the Sales Associate offer letter, employee handbook, job posting, and Denver applicant data.

Verified findings:

- The Sales Associate offer is $17.50 per hour.
- The Denver market rate in the dataset is $19.75 per hour.
- The offer is 11.4% below market.
- The handbook requires hourly retail pay at or above the local market median.
- The posting advertised an August target start.
- The offer letter proposed September 28.
- Two of 11 Sales Associate offers were accepted.
- Five of nine declines cited pay, three cited the delayed start date, and one accepted another offer.
- Six of eight Sales Associate positions remain open.

The documents show one connected problem: GreenThreads' pay and candidate timeline do not match its policy or recruiting message, and the applicant outcomes show the hiring risk.

